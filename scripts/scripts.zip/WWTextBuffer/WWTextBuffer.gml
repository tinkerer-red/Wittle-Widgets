#region jsDoc
/// @func	WWTextBuffer()
/// @desc	Text storage component backed by a GML buffer. Stores the canonical
///		  text as both a buffer_string and a cached string. Provides simple
///		  editing and query operations using 0-based indices and [start,end)
///		  semantics. Does not know about layout, cursors, or rendering.
/// @returns {Struct.WWTextBuffer}
#endregion
function WWTextBuffer() : WWCore() constructor {
	debug_name = "WWTextBuffer";
	
	#region Public
	
		#region Builder Functions
		
			#region jsDoc
			/// @func	set_text()
			/// @desc	Replace the entire text stored in the buffer.
			/// @self    WWTextBuffer
			/// @param   {String} text : New text to store.
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static set_text = function(_text) {
				_text = __filter_allowed__(_text);
				__set_text__(_text);
				return self;
			};
			
			#region jsDoc
			/// @func	set_allowed_char()
			/// @desc	Set the allowed character map. Any future set/insert will be
			///		  filtered to only include characters present in the map.
			///		  Accepts either:
			///		  - A string of allowed characters, or
			///		  - A struct where each key is a character.
			/// @self    WWTextBuffer
			/// @param   {Struct} allowed : Struct defining allowed characters.
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static set_allowed_char = function(_allowed) {
				__allowed_char_map__ = variable_clone(_allowed);
				
				// Re-filter existing __content__ to obey new allowed set.
				var _text = get_text();
				if (_text != "") {
					var _filtered = __filter_allowed__(_text);
					if (_filtered != _text) {
						clear_text();
						__set_text__(_filtered);
					}
				}
				
				return self;
			};
	
		#endregion
		
		#region Events
			
			
		#endregion
		
		#region Functions
			
			#region Getters
			
				#region jsDoc
				/// @func	get_text()
				/// @desc	Get the entire text stored in the buffer.
				/// @self    WWTextBuffer
				/// @returns {String}
				#endregion
				static get_text = function() {
					if (__is_dirty__) {
						if (buffer_exists(__buffer__)) {
							buffer_seek(__buffer__, buffer_seek_start, 0);
							var _text = buffer_read(__buffer__, buffer_text);
							__content__  = _text;
							__length__   = string_length(_text);
						}
						else {
							__content__  = "";
							__length__   = 0;
						}
						__is_dirty__ = false;
					}
					return __content__;
				};
			
				#region jsDoc
				/// @func	get_size()
				/// @desc	Get the number of characters stored in the buffer.
				///		  (Used by select_all in WWTextField.)
				/// @self    WWTextBuffer
				/// @returns {Real}
				#endregion
				static get_size = function() {
					if (__is_dirty__) {
						if (buffer_exists(__buffer__)) {
							buffer_seek(__buffer__, buffer_seek_start, 0);
							var _text = buffer_read(__buffer__, buffer_text);
							__content__  = _text;
							__length__   = string_length(_text);
						} else {
							__content__  = "";
							__length__   = 0;
						}
						__is_dirty__ = false;
					}
					return __length__;
				};
			
				#region jsDoc
				/// @func	get_substring()
				/// @desc	Get a substring using 0-based indices and [start,end) range.
				/// @self    WWTextBuffer
				/// @param   {Real} start_index : Inclusive start index (0-based).
				/// @param   {Real} end_index   : Exclusive end index (0-based).
				/// @returns {String}
				#endregion
				static get_substring = function(_start_index, _end_index) {
					var _start_clamp = clamp(_start_index, 0, get_size());
					var _end_clamp   = clamp(_end_index, 0, get_size());
		
					if (_end_clamp < _start_clamp) {
						var _swap_temp = _start_clamp;
						_start_clamp   = _end_clamp;
						_end_clamp	 = _swap_temp;
					}
		
					var _count = _end_clamp - _start_clamp;
					if (_count <= 0) {
						return "";
					}
		
					// GameMaker strings are 1-based.
					var _gm_start = _start_clamp + 1;
					return string_copy(get_text(), _gm_start, _count);
				};
			

				#region jsDoc
				/// @func	get_byte_index_from_index()
				/// @desc	Convert a 0-based character index to a 0-based UTF-8 byte index.
				/// 		This is used by the textbox editing code to call insert/erase which operate on byte indices.
				/// @self    WWTextBuffer
				/// @param	{Real} index
				/// @returns {Real}
				#endregion
				static get_byte_index_from_index = function(_index) {
					__ensure_byte_offsets__();
					var _char_count = __length__;
					if (_index <= 0) { return 0; }
					if (_index >= _char_count) { return __byte_total__; }
					return __byte_offsets__[_index];
				};

				#region jsDoc
				/// @func	get_index_from_byte_index()
				/// @desc	Convert a 0-based UTF-8 byte index to a 0-based character index.
				/// @self    WWTextBuffer
				/// @param	{Real} byte_index
				/// @returns {Real}
				#endregion
				static get_index_from_byte_index = function(_byte_index) {
					__ensure_byte_offsets__();
					if (_byte_index <= 0) { return 0; }
					if (_byte_index >= __byte_total__) { return __length__; }

					var _low = 0;
					var _high = __length__;
					while (_low <= _high) {
						var _mid = (_low + _high) div 2;
						var _mid_off = __byte_offsets__[_mid];
						if (_mid_off == _byte_index) {
							return _mid;
						}
						if (_mid_off < _byte_index) {
							_low = _mid + 1;
						}
						else {
							_high = _mid - 1;
						}
					}

					if (_high < 0) { return 0; }
					return _high;
				};

				#region jsDoc
				/// @func	get_allowed_char()
				/// @desc	Gets the allowed character struct.
				/// @self    WWTextBuffer
				/// @returns {Struct}
				#endregion
				static get_allowed_char = function() {
					return __allowed_char_map__;
				};
			#endregion
			
			#region jsDoc
			/// @func	destroy()
			/// @desc	Delete the underlying buffer. Do not use this instance after.
			/// @self    WWTextBuffer
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static destroy = function() {
				if (buffer_exists(__buffer__)) {
					buffer_delete(__buffer__);
				}
				if (buffer_exists(__temp_buffer__)) {
					buffer_delete(__temp_buffer__);
				}
				__buffer__ = -1;
				__content__ = "";
				__length__ = 0;
				__allowed_char_map__ = undefined;
				return self;
			};
			
			#region jsDoc
			/// @func	clear_text()
			/// @desc	Clear the buffer to an empty string.
			/// @self    WWTextBuffer
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static clear_text = function() {
				if (buffer_exists(__buffer__)) {
					buffer_resize(__buffer__, 0);
					buffer_resize(__buffer__, 65536);
					buffer_seek(__buffer__, buffer_seek_start, 0);
				}
	
				__content__   = "";
				__length__	= 0;
				__is_dirty__  = false;
	
				return self;
			};
			
			#region jsDoc
			/// @func	insert()
			/// @desc	Insert text at the given 0-based *byte* index. Existing bytes at and
			///         after that index are shifted to the right.
			/// @self    WWTextBuffer
			/// @param	{Real}  index : Insertion index (0-based, in bytes).
			/// @param	{String} text : Text to insert.
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static insert = function(_index, _text) {
				// Early out
				if (_text == "") { return self; }
				_text = __filter_allowed__(_text);
				if (_text == "") { return self; }
				
				// Ensure backing buffers exist
				if (!buffer_exists(__buffer__)) {
					__buffer__ = buffer_create(65536, buffer_grow, 1);
				}
				if (!buffer_exists(__temp_buffer__)) {
					__temp_buffer__ = buffer_create(65536, buffer_grow, 1);
				}
				
				var _insert_byte_length = string_byte_length(_text);
				
				// Get current used byte length
				var _current_text = get_text();
				var _current_byte_length = string_byte_length(_current_text);
				
				// Bytes on the right we need to preserve
				var _right_bytes = _current_byte_length - _index;
				if (_right_bytes < 0) {
					_right_bytes = 0;
				}
	
				// Copy right side into temp
				if (_right_bytes > 0) {
					buffer_copy(__buffer__, _index, _right_bytes, __temp_buffer__, 0);
				}
	
				// Write new text at insertion point
				buffer_seek(__buffer__, buffer_seek_start, _index);
				buffer_write(__buffer__, buffer_text, _text);
	
				// Copy preserved right side back after inserted text
				if (_right_bytes > 0) {
					var _dest_offset = _index + _insert_byte_length;
					buffer_copy(__temp_buffer__, 0, _right_bytes, __buffer__, _dest_offset);
				}
	
				// New terminator at end of text
				var _final_byte_length = _current_byte_length + _insert_byte_length;
				buffer_seek(__buffer__, buffer_seek_start, _final_byte_length);
				buffer_write(__buffer__, buffer_u8, 0);
	
				__is_dirty__ = true;
				__byte_offsets_dirty__ = true;
				return self;
			};
			
			#region jsDoc
			/// @func    erase()
			/// @desc    Erase bytes in the given 0-based index range (start, end).
			/// @self    WWTextBuffer
			/// @param   {Real} start : Start index (0-based, inclusive, in bytes).
			/// @param   {Real} end   : End index (0-based, exclusive, in bytes).
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static erase = function(_start, _end) {
				// No range to erase
				if (_start == _end) { return self; }
				
				// Ensure backing buffers exist
				if (!buffer_exists(__buffer__)) {
					__buffer__ = buffer_create(65536, buffer_grow, 1);
					return;
				}
				if (!buffer_exists(__temp_buffer__)) {
					__temp_buffer__ = buffer_create(65536, buffer_grow, 1);
				}
				
				var _current_text = get_text();
				var _current_byte_length = string_byte_length(_current_text);
	
				// Nothing to erase if empty
				if (_current_byte_length <= 0) { return self; }
				
				// Normalize so start <= end
				if (_start > _end) {
					var _temp_swap = _start;
					_start = _end;
					_end = _temp_swap;
				}
				
				// Bytes on the right to preserve (everything after _end)
				var _right_bytes = _current_byte_length - _end;
				if (_right_bytes <= 0) {
					_right_bytes = 0;
				}
				// Copy right side into temp
				if (_right_bytes > 0) {
					buffer_copy(__buffer__, _end, _right_bytes, __temp_buffer__, 0);
					buffer_copy(__temp_buffer__, 0, _right_bytes, __buffer__, _start);
				}
				
				// New terminator at end of shortened text
				var _final_byte_length = _start + _right_bytes;
				buffer_seek(__buffer__, buffer_seek_start, _final_byte_length);
				buffer_write(__buffer__, buffer_u8, 0);
				
				__is_dirty__ = true;
				__byte_offsets_dirty__ = true;
				return self;
			};
			
		#endregion
		
	#endregion
	
	#region Private
		
		#region Variables
			
			// Underlying GML buffer. Always contains the full string written as
			// buffer_string starting at offset 0.
			__buffer__ = buffer_create(65536, buffer_grow, 1);
			__temp_buffer__ = buffer_create(65536, buffer_grow, 1);
			
			// Cached string __content__ (your textbox currently reads this directly).
			__content__ = "";
			
			// Cached character length.
			__length__ = 0;
			
			// Optional allowed character map: struct where each key is a character.
			// If undefined, no filtering is applied.
			__allowed_char_map__ = undefined;
			
			// Denote if __content__ needs to be updated on next call to `.get_text()`
			__is_dirty__ = true;
				
				// Byte offset mapping: char index -> UTF-8 byte index
				__byte_offsets__ = [];
				__byte_total__ = 0;
				__byte_offsets_dirty__ = true;
			
			__textbox_parent__ = undefined;
			
		#endregion
		
		#region Functions
			#region jsDoc
			/// @func    __mark_dirty__()
			/// @ignore
			/// @desc    Marks cached text and byte offsets as dirty.
			/// @self    WWTextBuffer
			/// @returns {Undefined}
			#endregion
			static __mark_dirty__ = function() {
				__is_dirty__ = true;
				__byte_offsets_dirty__ = true;
			};
			
			#region jsDoc
			/// @func    __set_text__()
			/// @ignore
			/// @desc    Replaces the backing buffer contents and updates cached metadata.
			/// @self    WWTextBuffer
			/// @param   {String} text : New text content.
			/// @returns {Undefined}
			#endregion
			static __set_text__ = function(_text) {
				if (!buffer_exists(__buffer__)) {
					__buffer__ = buffer_create(0, buffer_grow, 1);
				}
				
				buffer_resize(__buffer__, 0);
				buffer_resize(__buffer__, 65536);
				buffer_seek(__buffer__, buffer_seek_start, 0);
				buffer_write(__buffer__, buffer_text, _text);
				
				__content__ = _text;
				__length__  = string_length(_text);
					__byte_offsets_dirty__ = true;
			};

			#region jsDoc
			/// @func    __ensure_byte_offsets__()
			/// @ignore
			/// @desc    Ensures the UTF-8 byte offset lookup table is up-to-date.
			/// @self    WWTextBuffer
			/// @returns {Undefined}
			#endregion
			static __ensure_byte_offsets__ = function() {
				if (!__byte_offsets_dirty__) { return; }

				if (!buffer_exists(__buffer__)) {
					__byte_offsets__ = [0];
					__byte_total__ = 0;
					__length__ = 0;
					__byte_offsets_dirty__ = false;
					return;
				}

				// Build char-index -> byte-index mapping by scanning the UTF-8 bytes in the backing buffer.
				// This avoids per-character string slicing (string_char_at), which becomes O(n^2) for large strings.
				var _buf = __buffer__;
				var _buf_size = buffer_get_size(_buf);
				var _pos = 0;
				var _char_count = 0;

				// Pass 1: count characters + find total used bytes (stop at first 0 byte).
				while (_pos < _buf_size) {
					var _b0 = buffer_peek(_buf, _pos, buffer_u8);
					if (_b0 == 0) { break; }

					var _step = 1;
					if (_b0 < 128) {
						_step = 1;
					} else if ((_b0 & 224) == 192) {
						_step = 2;
					} else if ((_b0 & 240) == 224) {
						_step = 3;
					} else if ((_b0 & 248) == 240) {
						_step = 4;
					} else {
						_step = 1;
					}

					_pos += _step;
					_char_count += 1;
				}

				var _byte_total = _pos;
				__byte_total__ = _byte_total;
				__length__ = _char_count;

				// Allocate/reuse array.
				var _need_len = _char_count + 1;
				if (is_undefined(__byte_offsets__) || array_length(__byte_offsets__) != _need_len) {
					__byte_offsets__ = array_create(_need_len, 0);
				}

				// Pass 2: fill offsets.
				_pos = 0;
				var _i = 0;
				repeat (_char_count) {
					__byte_offsets__[_i] = _pos;
					var _b = buffer_peek(_buf, _pos, buffer_u8);

					var _step2 = 1;
					if (_b < 128) {
						_step2 = 1;
					} else if ((_b & 224) == 192) {
						_step2 = 2;
					} else if ((_b & 240) == 224) {
						_step2 = 3;
					} else if ((_b & 248) == 240) {
						_step2 = 4;
					} else {
						_step2 = 1;
					}

					_pos += _step2;
					_i += 1;
				}
				__byte_offsets__[_char_count] = _byte_total;
				__byte_offsets_dirty__ = false;
			};
			
			#region jsDoc
			/// @func    __filter_allowed__()
			/// @ignore
			/// @desc    Normalizes newlines and filters text through the allowed character map.
			/// @self    WWTextBuffer
			/// @param   {String} text : Input text.
			/// @returns {String}
			#endregion
			static __filter_allowed__ = function(_text) {
				if (is_undefined(__allowed_char_map__)) {
					_text = string_replace_all(_text, "\r\n", "\n")
					_text = string_replace_all(_text, "\r", "\n")
					return _text;
				}
				
				static __args = {
					buff : buffer_create(1, buffer_grow, 1),
				}
				static __fn = method(__args, function(_char, _index) {
					if (__allowed_char_map__[$ _char]) {
						buffer_write(buff, buffer_text, _char);
					}
				});
				__args.__allowed_char_map__ = __allowed_char_map__;
				
				buffer_resize(__args.buff, string_byte_length(_text));
				buffer_seek(__args.buff, buffer_seek_start, 0);
				
				string_foreach(_text, __fn);
					
				// Write a null terminator so the resulting string ends correctly.
				buffer_write(__args.buff, buffer_u8, 0);
					
				buffer_seek(__args.buff, buffer_seek_start, 0);
				var _new_text = buffer_read(__args.buff, buffer_string);
				
				buffer_resize(__args.buff, 0);
				
				return _new_text;
			};
			
			#region jsDoc
			/// @func    __set_textbox__()
			/// @ignore
			/// @desc    Associates a textbox component with this buffer.
			/// @self    WWTextBuffer
			/// @param   {Any} comp : The textbox component.
			/// @returns {Struct.WWTextBuffer}
			#endregion
			static __set_textbox__ = function(_comp) {
				__textbox_parent__ = _comp;
				return self;
			}
			
		#endregion
		
	#endregion
	
}
